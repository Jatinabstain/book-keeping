export default function ProfilePage() {
    return (
      <>Profile page</>
    );
  }
  