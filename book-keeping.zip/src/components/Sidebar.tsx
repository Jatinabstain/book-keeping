"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import Image from "next/image";


export default function Sidebar() {
    const [isOpen, setIsOpen] = useState(false);
    const [dropUp, setDropUp] = useState(false);
    const buttonRef = useRef<HTMLButtonElement>(null);
    const menuRef = useRef<HTMLUListElement>(null);

    const toggleDropdown = () => {
        setIsOpen(!isOpen);
    };

    // Detect available space on toggle
    useEffect(() => {
        if (isOpen && buttonRef.current && menuRef.current) {
            const buttonRect = buttonRef.current.getBoundingClientRect();
            const menuHeight = menuRef.current.offsetHeight;
            const spaceBelow = window.innerHeight - buttonRect.bottom;

            setDropUp(spaceBelow < menuHeight + 10); // open upward if not enough space
        }
    }, [isOpen]);

    return (
        <>
            <section className="sidebar sticky top-0 z-10 flex flex-col shrink-0">
                <div className="navigation logo">
                    <Link href="/dashboard">
                        <Image
                            src="next.svg"
                            alt="Logo"
                            width={120}
                            height={100}
                        />
                    </Link>
                </div>
                <div className="scrollarea grow">
                    <ul className="menu">
                        <li>
                            <Link href="/dashboard"><i className="fi fi-rr-dashboard"></i> Dashboard</Link>
                        </li>
                        <li>
                            <Link href="#"><i className="fi fi-rr-list-check"></i> Task</Link>
                        </li>
                    </ul>
                    <hr className="divider opacity-100" />
                </div>
                <div className="relative inline-block text-left">
                    <hr className="border opacity-100" />
                    <button
                        ref={buttonRef}
                        onClick={toggleDropdown}
                        className="dropdown-toggle user_setting_menu flex items-center gap-2"
                    >
                        <i className="fi fi-rr-user"></i> Name
                    </button>

                    {isOpen && (
                        <ul
                            ref={menuRef}
                            className={`absolute right-0 w-48 bg-gray-800 text-white shadow-lg rounded-md z-50 text-sm transition-all ${dropUp ? "bottom-full mb-2" : "top-full mt-2"
                                }`}
                        >
                            <li>
                                <Link href="/dashboard/profile" className="block px-4 py-2 hover:bg-gray-700">
                                    Profile
                                </Link>
                            </li>
                            <li>
                                <hr className="my-1 border-gray-600" />
                            </li>
                            <li>
                                <button
                                    onClick={() => {
                                        // handle logout
                                    }}
                                    className="w-full text-left px-4 py-2 hover:bg-gray-700"
                                >
                                    Logout
                                </button>
                            </li>
                        </ul>
                    )}
                </div>
            </section>
        </>
    );
}
